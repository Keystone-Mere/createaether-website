/** Fractions of the existing 960 x 540 scene coordinate space. */
export type ScenePoint = readonly [number, number];
export type EffectBoundary =
  | { readonly kind: 'rectangle'; readonly x: number; readonly y: number; readonly width: number; readonly height: number }
  | { readonly kind: 'polygons'; readonly polygons: readonly (readonly ScenePoint[])[] };

/** Existing cover geometry. Alternative/user backgrounds need their own measured masks. */
export const sceneEffectBoundaries = {
  retreat: { kind: 'rectangle', x: .133, y: .079, width: .744, height: .611 },
  storm: {
    kind: 'polygons',
    polygons: [[[0, .08], [.23, 0], [1, 0], [1, 1], [.69, 1], [0, .86]]],
  },
  christmas: {
    kind: 'polygons',
    polygons: [
      [[.233, .015], [.438, .015], [.438, .465], [.270, .465], [.233, .320]],
      [[.460, .027], [.562, .027], [.562, .218], [.460, .218]],
      [[.460, .239], [.562, .239], [.562, .405], [.530, .415], [.520, .465], [.460, .465]],
    ],
  },
} as const satisfies Record<string, EffectBoundary>;

/** Preserve existing selection rules: cabin scene first, otherwise preset and motion. */
export function particleBoundary(sceneId: string | undefined, preset: string, motion: string): EffectBoundary | null {
  if (sceneId === 'retreat') return sceneEffectBoundaries.retreat;
  if (preset === 'christmas-snow' && motion === 'snow') return sceneEffectBoundaries.christmas;
  if (preset === 'storm-rain' && motion === 'rain') return sceneEffectBoundaries.storm;
  return null;
}
