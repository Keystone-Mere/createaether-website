export interface AudioSettings {
  enabled: boolean;
  volume: number;
  track: string;
  /** Optional atmosphere layer; older saved experiences remain valid. */
  layerVolume?: number;
}

export interface AtmosphereSettings {
  particles: boolean;
  lighting: boolean;
  fog: boolean;
}

export interface EnvironmentSettings {
  colour: string;
}

export interface LightingSettings {
  preset: string;
  colour: string;
  intensity: number;
  pulse: boolean;
  speed: number;
}

export interface FogSettings {
  preset: string;
  colour: string;
  density: number;
  speed: number;
}

export interface ParticleSettings {
  preset: string;
  motion?: "rise" | "wander" | "flow" | "rain" | "snow" | "burst";

  count: number;
  colour: string;
  glow: number;

  minRadius: number;
  maxRadius: number;

  minSpeed: number;
  maxSpeed: number;

  drift: number;

  minOpacity: number;
  maxOpacity: number;

  minLifetime: number;
  maxLifetime: number;
}

export interface TransitionSettings {
  duration: number;
  easing: string;
}

export interface Experience {
  /** Omitted on legacy v1 files; added when loaded or saved. */
  formatVersion?: 1;
  /** Scene stays independent of particle and audio preset choices. */
  smoke?: { enabled: boolean; amount: number };
  sceneId?: string;
  /** Embedded, compressed JPG for user-created backgrounds. */
  background?: string;
  /** Optional bundled alternative; omitted means the original scene image. */
  backgroundId?: string;
  id: string;
  name: string;
  description: string;
  status: string;

  audio: AudioSettings;
  atmosphere: AtmosphereSettings;

  /** Optional so experiences exported before the colour editor remain importable. */
  environment?: EnvironmentSettings;

  lighting: LightingSettings;
  fog: FogSettings;
  particles: ParticleSettings;

  transition: TransitionSettings;
}
