/** Bundled choices use known local assets, never arbitrary imported URLs. */
export const backgroundChoices = [
    { id: 'retreat-winter', sceneId: 'retreat', name: 'Winter landscape', src: '/images/experience-covers/retreat-winter.jpg' },
    { id: 'temple-mountain', sceneId: 'temple', name: 'Mountain temple', src: '/images/experience-covers/temple-mountain.jpg' },
    { id: 'temple-angkor', sceneId: 'temple', name: 'Angkor-inspired sanctuary', src: '/images/experience-covers/temple-angkor.jpg' },
    { id: 'forest-stream', sceneId: 'forest', name: 'Fern grotto', src: '/images/experience-covers/forest-fern-grotto.png' },
    { id: 'forest-dusk', sceneId: 'forest', name: 'Redwood sanctuary', src: '/images/experience-covers/forest-redwood-sanctuary.png' },
    { id: 'ocean-cove', sceneId: 'ocean', name: 'Turquoise cove', src: '/images/experience-covers/ocean-cove.png' },
    { id: 'ocean-atlantic', sceneId: 'ocean', name: 'Atlantic coast', src: '/images/experience-covers/ocean-atlantic.png' },
    { id: 'christmas-fireside', sceneId: 'christmas', name: 'Snowy forest retreat', src: '/images/experience-covers/christmas-forest-retreat.png' },
    { id: 'christmas-village', sceneId: 'christmas', name: 'Christmas conservatory', src: '/images/experience-covers/christmas-conservatory.png' },
    { id: 'festival-woodland', sceneId: 'festival', name: 'Woodland festival', src: '/images/experience-covers/festival-woodland.png' },
    { id: 'festival-waterfront', sceneId: 'festival', name: 'Waterfront festival', src: '/images/experience-covers/festival-waterfront.png' },
    { id: 'storm-city', sceneId: 'storm', name: 'Rainy city terrace', src: '/images/experience-covers/storm-city.png' },
    { id: 'storm-coast', sceneId: 'storm', name: 'Coastal storm shelter', src: '/images/experience-covers/storm-coast.png' },
] as const;

export function isBackgroundId(value: unknown): value is string {
    return typeof value === 'string' && backgroundChoices.some(choice => choice.id === value);
}

export function backgroundSource(experience: { id: string; sceneId?: string; background?: string; backgroundId?: string }): string {
    if (experience.background) return experience.background;
    const choice = backgroundChoices.find(choice => choice.id === experience.backgroundId);
    if (choice) return choice.src;
    const scene = experience.sceneId ?? experience.id.split('-')[0];
    const covers: Record<string, string> = { retreat:'retreat', temple:'temple', forest:'forest', ocean:'ocean', christmas:'christmas', storm:'storm-balcony', festival:'festival-evening' };
    return `/images/experience-covers/${covers[scene] ?? 'temple'}.jpg`;
}
